# Codeigniter 3 Tutorial - Simple Authentication and Authorization

This is final code for tutorial **Codeigniter 3 Tutorial - Simple Authentication and Authorization**

