<div class="container main">   
  	<div class="page-header">
  		<h1>About us</h1>
  	</div>
	
	  <div class="well">			
			
		</div>
  </div>