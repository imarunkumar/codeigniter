
  	
    <div class="container main">   
    	<div class="page-header">
    		<h1>Dashboard</h1>
    	</div>
		
		<div class="well">
			<h2>Welcome</h2>
			<p>Welcome to the page</p>
		</div>
    </div>

