<form method="post" action="<?php echo site_url('Auth/savingdata'); ?>">  
<div class="jumbotron" align="center">
<h2>Register</h2> 
</div>
<div align="center">
<input type="text" name="username" placeholder="username" style="text-align: center;" required="required">
<br><br>

<input type="password"  id="password" name="password" placeholder="password" style="text-align: center;" required="required">
<br><br>

<input type="password" id="passwordConfirm" name="passwordaga" placeholder="password again" style="text-align: center;"required="required">
<br><br>
<input type="email" name="email" placeholder="Email ID" style="text-align: center;"required="required">
<br>
<br>
<input type="reset" name="reset" class="btn btn-primary" value="clear">
<input type="submit" id="submit" name="save" class="btn btn-primary" value=" Register"/>
  <a href="<?php echo site_url("auth/") ?>" class="btn btn-primary">Login</a>
</div>
</form>
</div>