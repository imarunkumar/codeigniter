<div class="container main">   
  	<div class="page-header">
  		<h1>Blog</h1>
  	</div>
	
	  <div class="well">			
			
		</div>
  </div>